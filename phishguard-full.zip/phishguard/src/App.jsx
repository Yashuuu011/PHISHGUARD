import { useState } from 'react'
import Dashboard from './components/Dashboard.jsx'
import Scanner from './components/Scanner.jsx'

export default function App() {
  const [page, setPage] = useState('dashboard')

  return (
    <div>
      {page === 'dashboard' && <Dashboard onNavigate={setPage} />}
      {page === 'scanner'   && <Scanner   onNavigate={setPage} />}
    </div>
  )
}
